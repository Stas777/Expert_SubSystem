// D_Menu.cpp : implementation file
//

#include "stdafx.h"
#include "ess.h"
#include "essdoc.h"
#include "D_Menu.h"
#include "mtreectrl.h"
#include "D_Label.h"
#include "D_LabMod.h"
#include "D_LabStrat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////////
// CD_Menu dialog


CD_Menu::CD_Menu(CWnd* pParent /*=NULL*/)
	: CDialog(CD_Menu::IDD, pParent)
{
	//{{AFX_DATA_INIT(CD_Menu)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CD_Menu::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CD_Menu)
	DDX_Control(pDX, IDC_TREE1, m_mytreectrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CD_Menu, CDialog)
	//{{AFX_MSG_MAP(CD_Menu)
	ON_BN_CLICKED(IDC_NEW, OnNew)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_EDITLAB, OnEditlab)
	ON_BN_CLICKED(IDC_NEW2, OnNew2)
	ON_BN_CLICKED(IDC_EDITMOD, OnEditmod)
	ON_BN_CLICKED(IDC_EDITSTRAT, OnEditstrat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



///////////////////////////////////////////////////////////////////////////
// CD_Menu message handlers

///////////////////////////////////////////////////////////////////////////
BOOL CD_Menu::OnInitDialog() 
{
	CDialog::OnInitDialog();

  CImageList          *pImageList;
	CBitmap             bitmap;
	UINT                nID;
	TV_INSERTSTRUCT     curTreeItem;
  char buf[100];
	
	pImageList = new CImageList();
	pImageList->Create(20, 18, ILC_MASK, 6, 4);

	for (nID = IDB_BITMAP1; nID <= IDB_BITMAP8; nID++)
	{
		bitmap.LoadBitmap(nID);
		pImageList->Add(&bitmap, (COLORREF)0xFFFFFF);
		bitmap.DeleteObject();
	}

	m_mytreectrl.SetImageList(pImageList, TVSIL_NORMAL);

  if (theApp.m_pDoc->m_ArrayMenu.GetSize() == 0)
  {
		curTreeItem.hParent = NULL;
		curTreeItem.item.iImage = 4;
		curTreeItem.item.iSelectedImage = 5;
		curTreeItem.item.pszText = "������� ��������� ���������";
		curTreeItem.item.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT;
    m_NewHandle[0]=m_mytreectrl.InsertItem(&curTreeItem);
    m_mytreectrl.SetNewStyle(TVS_EDITLABELS, FALSE);
    m_mytreectrl.SetNewStyle(TVS_LINESATROOT, TRUE); 
  }
  else
  {
    for (int i=0; i< theApp.m_pDoc->m_ArrayMenu.GetSize(); i++)
    {
      CMenuESS *pMenu;
      pMenu = theApp.m_pDoc->m_ArrayMenu.GetAt(i);
      if (pMenu->m_hParent==NULL) // Root
      {
        curTreeItem.hParent = NULL;
		    curTreeItem.item.iImage = 4;
		    curTreeItem.item.iSelectedImage = curTreeItem.item.iImage + 1;
    		curTreeItem.item.pszText = pMenu->m_Label.GetBuffer(pMenu->m_Label.GetLength());
    		curTreeItem.item.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT;
        m_NewHandle[i]=m_mytreectrl.InsertItem(&curTreeItem);
      }
      else
      {
        int j=0;
        for (; j< i; j++)
        {
          CMenuESS *pMenu1 = theApp.m_pDoc->m_ArrayMenu.GetAt(j);
          if (pMenu->m_hParent==pMenu1->m_hOwn)      break;
        }
        curTreeItem.hParent = m_NewHandle[j];
        curTreeItem.item.pszText = pMenu->m_Label.GetBuffer(pMenu->m_Label.GetLength());
        if (pMenu->m_Name == "")
          if (pMenu->m_Label == "???") curTreeItem.item.iImage = 6;
          else                         curTreeItem.item.iImage = 0;
        else
        {
  		    curTreeItem.item.iImage = 2;
          CString w = "(" + pMenu->m_Name + ")  " + pMenu->m_Label;
          strcpy(buf, (const char *)w);
          curTreeItem.item.pszText = buf;
        }

		    curTreeItem.item.iSelectedImage = curTreeItem.item.iImage + 1;
    		
    		curTreeItem.item.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT;
        m_NewHandle[i]=m_mytreectrl.InsertItem(&curTreeItem);
      }
    }
  }
  return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

///////////////////////////////////////////////////////////////////////////
void CD_Menu::OnNew() 
{
	HTREEITEM   m_h;

  UpdateData();
  TV_INSERTSTRUCT     curTreeItem;
  m_h = m_mytreectrl.GetSelectedItem( );
	curTreeItem.hParent = m_mytreectrl.GetParentItem(m_h);
  if (curTreeItem.hParent!=NULL)
    m_h = curTreeItem.hParent;
	m_mytreectrl.InsertItem("???",6,7,m_h, TVI_LAST );
  m_mytreectrl.Expand(m_h, TVE_EXPAND );
  UpdateData(FALSE);
}

///////////////////////////////////////////////////////////////////////////
void CD_Menu::OnNew2() 
{
	HTREEITEM   m_h, m_h1;
  CString W,W1;
  int c,c_w, c1, c1_w;
  UpdateData();
  m_h = m_mytreectrl.GetSelectedItem( );
  m_h1 = m_mytreectrl.GetPrevSiblingItem(m_h);
  if (m_h1==NULL) return;
  W = m_mytreectrl.GetItemText(m_h);
  W1 = m_mytreectrl.GetItemText(m_h1);
  m_mytreectrl.GetItemImage(m_h, c, c_w);
  m_mytreectrl.GetItemImage(m_h1, c1, c1_w);

  m_mytreectrl.SetItemText(m_h,W1);
  m_mytreectrl.SetItemText(m_h1,W);
  m_mytreectrl.SetItemImage(m_h,c1,c1_w);
  m_mytreectrl.SetItemImage(m_h1,c,c_w);
  m_mytreectrl.Select(m_h1,TVGN_CARET);
  UpdateData(FALSE);
}

///////////////////////////////////////////////////////////////////////////
void CD_Menu::OnDelete() 
{
  CString s;
  int Res;
  if (m_mytreectrl.GetParentItem(m_mytreectrl.GetSelectedItem( ))== NULL)
  {
    AfxMessageBox("�������� ������� ������� ������!");
    return;
  }

  s = m_mytreectrl.GetItemText(m_mytreectrl.GetSelectedItem( ));
  Res = AfxMessageBox("�� ������������� ������ ������� �������\n" + s + "?",
        MB_YESNO|MB_ICONSTOP);
  if (Res == IDYES)
  {
   	HTREEITEM hFirstChild, hLastChild;
    hLastChild = m_mytreectrl.GetParentItem(m_mytreectrl.GetSelectedItem( ));
    m_mytreectrl.DeleteItem(m_mytreectrl.GetSelectedItem( ));
  
    hFirstChild = m_mytreectrl.GetChildItem(hLastChild);

    if (hFirstChild==NULL)
    {
      hFirstChild = m_mytreectrl.GetNextItem(hFirstChild, TVGN_NEXT);
      if (hFirstChild == NULL) {
        if (m_mytreectrl.GetRootItem( ) != hLastChild)
          m_mytreectrl.SetItemImage(hLastChild, 6,7);
      }
    }

  }
}

///////////////////////////////////////////////////////////////////////////
void CD_Menu::OnEditlab() 
{
  if (m_mytreectrl.ItemHasChildren(m_mytreectrl.GetSelectedItem( )))
  {
    CD_Label dlg;
    dlg.m_Text = m_mytreectrl.GetItemText(m_mytreectrl.GetSelectedItem( ));
    if (dlg.DoModal()==IDOK)
      m_mytreectrl.SetItemText(m_mytreectrl.GetSelectedItem( ),dlg.m_Text);
	}
}

void CD_Menu::OnOK() 
{
  HTREEITEM hCurrent = m_mytreectrl.GetRootItem(), hCurrent1;
  theApp.m_pDoc->m_ArrayMenu.RemoveAll();
  CMenuESS *pMenu;
  CString W, key;
  TVITEM item;
  TCHAR szText[200];

  pMenu = new CMenuESS;
  pMenu->m_hParent = NULL;
  pMenu->m_hOwn = hCurrent;
  item.hItem = hCurrent;
  item.mask = TVIF_TEXT | TVIF_HANDLE;
  item.pszText = szText;
  item.cchTextMax = 200;
  m_mytreectrl.GetItem(&item);
  W = item.pszText;
  pMenu->m_Name = "";
  pMenu->m_Label = W;
  theApp.m_pDoc->m_ArrayMenu.Add(pMenu);

  hCurrent = m_mytreectrl.GetNextItem(hCurrent, TVGN_CHILD);
  while (hCurrent != NULL)
  {
    pMenu = new CMenuESS;
    pMenu->m_hParent = m_mytreectrl.GetParentItem(hCurrent);
    pMenu->m_hOwn = hCurrent;
    item.hItem = hCurrent;
    item.mask = TVIF_TEXT | TVIF_HANDLE;
    item.pszText = szText;
    item.cchTextMax = 199;
    m_mytreectrl.GetItem(&item);

    W = item.pszText;
    if (W[0] == '(')
    {
      W = W.Mid(1);
      int i = W.Find(")  ");
      if (i>0)
      {
        pMenu->m_Name = W.Left(i);
        pMenu->m_Label = W.Mid(i+3);  
      }
      else
      {
        pMenu->m_Name = "";
        pMenu->m_Label = W;
      }
    }
    else if (W[0] == '@')
    {
      pMenu->m_Name = "@";
      pMenu->m_Label = W;
    }
    else 
    {
      pMenu->m_Name = "";
      pMenu->m_Label = W;
    }
    theApp.m_pDoc->m_ArrayMenu.Add(pMenu);

    hCurrent1 = m_mytreectrl.GetNextItem(hCurrent, TVGN_CHILD);
    if (hCurrent1 == NULL) // No more child
    {
hod0:
      hCurrent1 = m_mytreectrl.GetNextItem(hCurrent, TVGN_NEXT);
      if (hCurrent1 == NULL) // No more brothers
      {
        hCurrent = m_mytreectrl.GetParentItem(hCurrent);
        if (hCurrent==NULL) break;
        goto hod0;
      }
      else
        hCurrent = hCurrent1;
    }
    else
      hCurrent = hCurrent1;
  }  
	CDialog::OnOK();
}


void CD_Menu::OnEditmod() 
{
  if (!m_mytreectrl.ItemHasChildren(m_mytreectrl.GetSelectedItem( )))
  {
    CD_LabMod dlg;
    dlg.m_Text = m_mytreectrl.GetItemText(m_mytreectrl.GetSelectedItem( ));
    if (dlg.DoModal()==IDOK)
    {
      m_mytreectrl.SetItemText(m_mytreectrl.GetSelectedItem( ),dlg.m_Text);
      m_mytreectrl.SetItemImage(m_mytreectrl.GetSelectedItem( ),2,3);
    }
  }
}

void CD_Menu::OnEditstrat() 
{
  if (!m_mytreectrl.ItemHasChildren(m_mytreectrl.GetSelectedItem( )))
  {
    CD_LabStrat dlg;
    dlg.m_Text = m_mytreectrl.GetItemText(m_mytreectrl.GetSelectedItem( ));
    if (dlg.DoModal()==IDOK)
    {
      m_mytreectrl.SetItemText(m_mytreectrl.GetSelectedItem( ),"(@)  @_"+dlg.m_Text);
      m_mytreectrl.SetItemImage(m_mytreectrl.GetSelectedItem( ),2,3);
    }
  }
}
