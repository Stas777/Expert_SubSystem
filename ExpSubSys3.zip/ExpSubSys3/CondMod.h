#if !defined(AFX_CONDMOD_H__207CEDF7_9B50_4DAC_BFCC_A11D78928872__INCLUDED_)
#define AFX_CONDMOD_H__207CEDF7_9B50_4DAC_BFCC_A11D78928872__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CondMod.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCondMod dialog

class CCondMod : public CDialog
{
// Construction
public:
	CCondMod(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCondMod)
	enum { IDD = IDD_CONDMOD };
	CListBox	m_ListExp;
	CString	m_Formula;
	//}}AFX_DATA
  CProduction *m_pProd;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCondMod)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
  void CreateForm(int M);
  CString L_Ed(CExpres * pExpres);
  CString N_Ed(CExpres * pExpres);
  CString S_Ed(CExpres * pExpres);
  void OnNew(int Type, CString Formula);
	// Generated message map functions
	//{{AFX_MSG(CCondMod)
	virtual BOOL OnInitDialog();
	afx_msg void OnBForm();
	afx_msg void OnBNew();
	afx_msg void OnBNew2();
	afx_msg void OnBNew3();
	afx_msg void OnBEdit();
	afx_msg void OnBDel();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONDMOD_H__207CEDF7_9B50_4DAC_BFCC_A11D78928872__INCLUDED_)
