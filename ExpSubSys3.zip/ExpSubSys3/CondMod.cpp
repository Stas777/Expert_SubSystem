// CondMod.cpp : implementation file
//

#include "stdafx.h"
#include "ess.h"
#include "CondMod.h"
#include "essdoc.h"
#include "d_log.h"
#include "d_num.h"
#include "d_str.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCondMod dialog


CCondMod::CCondMod(CWnd* pParent /*=NULL*/)
	: CDialog(CCondMod::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCondMod)
	m_Formula = _T("");
	//}}AFX_DATA_INIT
}


void CCondMod::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCondMod)
	DDX_Control(pDX, IDC_LIST1, m_ListExp);
	DDX_Text(pDX, IDC_EDIT1, m_Formula);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCondMod, CDialog)
	//{{AFX_MSG_MAP(CCondMod)
	ON_BN_CLICKED(IDC_B_FORM, OnBForm)
	ON_BN_CLICKED(IDC_B_NEW, OnBNew)
	ON_BN_CLICKED(IDC_B_NEW2, OnBNew2)
	ON_BN_CLICKED(IDC_B_NEW3, OnBNew3)
	ON_BN_CLICKED(IDC_B_EDIT, OnBEdit)
	ON_BN_CLICKED(IDC_B_DEL, OnBDel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCondMod message handlers

BOOL CCondMod::OnInitDialog() 
{
  CExpres *pExpres;
  int i,k;
    CDialog::OnInitDialog();
  k = m_pProd->m_ArrayExpression.GetSize();  
  if (k) {
    for (i=0; i<k; i++) {
      pExpres = m_pProd->m_ArrayExpression.GetAt(i);
      m_ListExp.AddString(pExpres->m_Formula);
    }
    m_ListExp.SetCurSel(0);
  }
  
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//----------------------------------------------------------- CreateForm
void CCondMod::CreateForm(int M)
{ if (M) OnBForm(); 
  m_Formula = m_pProd->CreateCondition();
  UpdateData(FALSE);
}


//----------------------------------------------------------- OnBForm
void CCondMod::OnBForm() 
{ int Res;
  CD_Form dlg;
  UpdateData(TRUE);  
  dlg.m_Formula = m_pProd->m_Formula;
  if (m_pProd->m_Formula.IsEmpty()) return;
  dlg.m_ArrayExpression = &m_pProd->m_ArrayExpression;
  Res = dlg.DoModal();
  if (Res == IDOK) {
    m_pProd->m_Formula = dlg.m_Formula; 
    m_Formula = m_pProd->CreateCondition();
    UpdateData(FALSE);
  }                       
}


//----------------------------------------------------------- OnNew
void CCondMod::OnNew(int Type, CString Formula)
{ CExpres * pExpres;
  CString W,W1;
  char buf[10];
  int Res;
  pExpres = new CExpres();
  pExpres->m_Formula = Formula;
  pExpres->m_Type = Type;
  Res = m_pProd->m_ArrayExpression.Add(pExpres);
  m_ListExp.AddString(pExpres->m_Formula);
  m_ListExp.SelectString(0,pExpres->m_Formula);
  if (m_pProd->m_Formula.IsEmpty()) m_pProd->m_Formula="{1}";
  else {
    sprintf(buf,"{%u}",Res+1);
    W = m_pProd->m_Formula;  W1 = " & "; W1 +=buf;
    if (W.Find('|')>=0 ) { W = "("+ m_pProd->m_Formula; W += ")"; }
    m_pProd->m_Formula = W + W1;  
  }
  CWnd* pWnd; pWnd = GetDlgItem(IDOK); pWnd->EnableWindow(TRUE);
  CreateForm(1);
}

//----------------------------------------------------------- OnNewLog
void CCondMod::OnBNew() 
{ CD_Log dlg;
  UpdateData(TRUE);  
  if (dlg.DoModal() == IDOK) { OnNew(0, dlg.m_Formula); }     
}

//----------------------------------------------------------- OnNewNum
void CCondMod::OnBNew2() 
{ CD_Num dlg;
  UpdateData(TRUE);  
 if (dlg.DoModal() == IDOK) { OnNew(1, dlg.m_Formula); }     
}

//----------------------------------------------------------- OnNewStr
void CCondMod::OnBNew3() 
{ CD_Str dlg;
  UpdateData(TRUE);  
 if (dlg.DoModal() == IDOK) { OnNew(2, dlg.m_Formula); }     
}

//----------------------------------------------------------- L_Ed
CString CCondMod::L_Ed(CExpres * pExpres)
{ CD_Log dlg;
  dlg.m_Formula = pExpres->m_Formula;
  if (dlg.DoModal() == IDOK) return dlg.m_Formula;
  else return "";
}

//----------------------------------------------------------- N_Ed
CString CCondMod::N_Ed(CExpres * pExpres)
{ CD_Num dlg;
  dlg.m_Formula = pExpres->m_Formula;
  if (dlg.DoModal() == IDOK) return dlg.m_Formula;
  else return "";
}

//----------------------------------------------------------- S_Ed
CString CCondMod::S_Ed(CExpres * pExpres)
{ CD_Str dlg;
  dlg.m_Formula = pExpres->m_Formula;
  if (dlg.DoModal() == IDOK) return dlg.m_Formula;
  else return "";
}


void CCondMod::OnBEdit() 
{ CExpres * pExpres;
  int i;
  CString W;
  if (m_ListExp.GetCount() == 0) return;
  UpdateData(TRUE);  
  i = m_ListExp.GetCurSel();
  pExpres = m_pProd->m_ArrayExpression.GetAt(i);
  switch (pExpres->m_Type) {
  case 0: W = L_Ed(pExpres); break;
  case 1: W = N_Ed(pExpres); break;
  case 2: W = S_Ed(pExpres); break;
  default: return;
  }
  if (W.IsEmpty()) return;
  pExpres->m_Formula = W;
  m_ListExp.DeleteString(i);
  m_ListExp.InsertString(i, (const char *) pExpres->m_Formula );
  m_ListExp.SelectString(0, pExpres->m_Formula);
  CreateForm(0);
}

void CCondMod::OnBDel() 
{
CString W;
  CExpres * pExpres;
  int Res,i;
  char buf[10];
  if (m_ListExp.GetCount() == 0) return;
  UpdateData(TRUE);  
  i = m_ListExp.GetCurSel();
  if (i<0) return;
  m_ListExp.GetText(i,W);
  Res = AfxMessageBox(IDS_DEL_EXP,MB_YESNO);
  if ( Res == IDYES ) {
    if (m_pProd->m_ArrayExpression.GetSize()<=2) goto hh1;
    Res = AfxMessageBox(IDS_DEL_EXP_CHANGE,MB_YESNO);
    if ( Res == IDYES ) {  
hh1:  pExpres = m_pProd->m_ArrayExpression.GetAt(i);
      m_pProd->m_ArrayExpression.RemoveAt(i); delete pExpres;
      m_ListExp.DeleteString(i); 
      if (m_pProd->m_ArrayExpression.GetSize()==0) 
        { m_pProd->m_Formula=""; m_Formula=""; UpdateData(FALSE); return; }
      if (i >=m_ListExp.GetCount())   i = m_ListExp.GetCount()-1;
      m_ListExp.SetCurSel(i);
      Res = m_pProd->m_ArrayExpression.GetSize();  
      m_pProd->m_Formula = "";
      for (i=0; i<Res; i++) {
        sprintf(buf,"{%u} & ",i+1); m_pProd->m_Formula += buf;
      }
      m_pProd->m_Formula = m_pProd->m_Formula.Left(m_pProd->m_Formula.GetLength()-3);
      m_Formula = m_pProd->CreateCondition();
      CreateForm(1);
    }
  }
	
}

void CCondMod::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CCondMod::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}
