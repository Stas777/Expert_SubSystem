// D_Label.cpp : implementation file
//

#include "stdafx.h"
#include "ess.h"
#include "D_Label.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CD_Label dialog


CD_Label::CD_Label(CWnd* pParent /*=NULL*/)
	: CDialog(CD_Label::IDD, pParent)
{
	//{{AFX_DATA_INIT(CD_Label)
	m_Text = _T("");
	//}}AFX_DATA_INIT
}


void CD_Label::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CD_Label)
	DDX_Text(pDX, IDC_EDIT2, m_Text);
	DDV_MaxChars(pDX, m_Text, 99);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CD_Label, CDialog)
	//{{AFX_MSG_MAP(CD_Label)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CD_Label message handlers
