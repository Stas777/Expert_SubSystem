// essdoc.h : interface of the CEssDoc class
//
#include "pfdoc.h"

class CD_AddStrategy;
/////////////////////////////////////////////////////////////////////////////

class CEssDoc : public CPFDoc
{
protected: // create from serialization only
    CEssDoc();
    DECLARE_SERIAL(CEssDoc)

// Attributes
public:
//    CStringArray   m_sTable;
//    CDoubleArray   m_dTable;

//---------------------------------------
    int m_ActStrategy;
    int m_ActProd;
//---------------------------------------
    int m_ActFrame;
    int m_ActSlot;
    CString   m_ActModul;
    // Implementation
public:
    CStrategy* CreateStrategy(CD_AddStrategy& dlg);
    void ChangeSelectionNextStrategyNo(BOOL bNext);
    void ChangeSelectionToStrategyNo(int nNewNo);
    void ChangeSelectionNextProdNo(BOOL bNext);
    void ChangeSelectionToProdNo(int nNewNo);
    void DeleteContents();
    void NextView(CRuntimeClass* pViewClass);
    
    void StratCom(); // For right button to StrategView
    void ProdEdit(CStrategy *pStrategy, CProduction *pProd);
    void SlotEdit(CFrame *pFrame, CSlot *pSlot);
//    int  AddToStr(CString s);
//    int  AddToNum(double d);
//    void GetAllConstToTable(int What);
    
    void ChangeSelectionNextFrameNo(BOOL bNext);
    void ChangeSelectionToFrameNo(int nNewNo);
    void ChangeSelectionNextSlotNo(BOOL bNext);
    void ChangeSelectionToSlotNo(int nNewNo);
    void FrameCom();
    
    virtual ~CEssDoc();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    virtual BOOL OnNewDocument();
    virtual BOOL OnOpenDocument(const char* pszPathName );
    virtual BOOL OnSaveDocument(const char* pszPathName);

// Generated message map functions
protected:
    //{{AFX_MSG(CEssDoc)
    afx_msg void OnAttributes();
    afx_msg void OnProgmoduls();
    afx_msg void OnStratAdd();
    afx_msg void OnStratDel();
    afx_msg void OnUpdateStrat(CCmdUI* pCmdUI);
    afx_msg void OnStratEdit();
    afx_msg void OnProdAdd();
    afx_msg void OnProdDel();
    afx_msg void OnUpdateProd(CCmdUI* pCmdUI);
    afx_msg void OnProdEdit();
    afx_msg void OnFrameAdd();
    afx_msg void OnFrameDel();
    afx_msg void OnUpdateFrame(CCmdUI* pCmdUI);
    afx_msg void OnFrameEdit();
    afx_msg void OnSlotAdd();
    afx_msg void OnSlotDel();
    afx_msg void OnSlotEdit();
    afx_msg void OnUpdateSlot(CCmdUI* pCmdUI);
	afx_msg void OnStratExport();
	afx_msg void OnStratImport();
	afx_msg void OnMenu();
	afx_msg void OnRepoz();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
