// D_LabStrat.cpp : implementation file
//

#include "stdafx.h"
#include "ess.h"
#include "essdoc.h"
#include "D_LabStrat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CD_LabStrat dialog


CD_LabStrat::CD_LabStrat(CWnd* pParent /*=NULL*/)
	: CDialog(CD_LabStrat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CD_LabStrat)
	//}}AFX_DATA_INIT
}


void CD_LabStrat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CD_LabStrat)
	DDX_Control(pDX, IDC_LIST1, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CD_LabStrat, CDialog)
	//{{AFX_MSG_MAP(CD_LabStrat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CD_LabStrat message handlers

BOOL CD_LabStrat::OnInitDialog() 
{
  POSITION pos;
  CString key;
  CStrategy *pStrategy;
  CDialog::OnInitDialog();

  for (pos = theApp.m_pDoc->m_MapStrategies.GetStartPosition(); pos!=NULL; )  {
    theApp.m_pDoc->m_MapStrategies.GetNextAssoc(pos, key, pStrategy);
    m_List.AddString(pStrategy->m_Name);
  }  
  m_List.SetCurSel(0);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CD_LabStrat::OnOK() 
{
  UpdateData(TRUE);
  m_List.GetText(m_List.GetCurSel(),m_Text);
	CDialog::OnOK();
}
