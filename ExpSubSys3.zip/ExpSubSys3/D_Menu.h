#if !defined(AFX_D_MENU_H__D8D9D658_0C88_416C_BC12_637B4AAB2A12__INCLUDED_)
#define AFX_D_MENU_H__D8D9D658_0C88_416C_BC12_637B4AAB2A12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// D_Menu.h : header file
//
#include "mtreectrl.h"

/////////////////////////////////////////////////////////////////////////////
// CD_Menu dialog

class CD_Menu : public CDialog
{
// Construction
public:
	CD_Menu(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CD_Menu)
	enum { IDD = IDD_MENU };
	CMyTreeCtrl	m_mytreectrl;
	//}}AFX_DATA

	HTREEITEM   m_hitemDrag;
	HTREEITEM   m_hitemDrop;
  HTREEITEM   m_NewHandle[200];
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CD_Menu)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CD_Menu)
	virtual BOOL OnInitDialog();
	afx_msg void OnNew();
	afx_msg void OnDelete();
	afx_msg void OnEditlab();
	virtual void OnOK();
	afx_msg void OnNew2();
	afx_msg void OnEditmod();
	afx_msg void OnEditstrat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_D_MENU_H__D8D9D658_0C88_416C_BC12_637B4AAB2A12__INCLUDED_)
