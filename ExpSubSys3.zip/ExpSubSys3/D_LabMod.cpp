// D_LabMod.cpp : implementation file
//

#include "stdafx.h"
#include "ess.h"
#include "essdoc.h"
#include "D_LabMod.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CD_LabMod dialog


CD_LabMod::CD_LabMod(CWnd* pParent /*=NULL*/)
	: CDialog(CD_LabMod::IDD, pParent)
{
	//{{AFX_DATA_INIT(CD_LabMod)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CD_LabMod::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CD_LabMod)
	DDX_Control(pDX, IDC_LIST1, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CD_LabMod, CDialog)
	//{{AFX_MSG_MAP(CD_LabMod)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CD_LabMod message handlers


BOOL CD_LabMod::OnInitDialog() 
{
  POSITION pos;
  CString key, W;
  CProgMod *pProgMod;
  CDialog::OnInitDialog();
  int cxEachStop =60;

  for (pos = theApp.m_pDoc->m_MapProgModuls.GetStartPosition(); pos!=NULL; )  {
    theApp.m_pDoc->m_MapProgModuls.GetNextAssoc(pos, key, pProgMod);
    W = key + "\t" + pProgMod->m_Menu;
    m_List.AddString(W);
  }  
  m_List.SetTabStops(1,&cxEachStop);

  m_List.SetCurSel(0);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CD_LabMod::OnOK() 
{
  CString key, W;
  UpdateData(TRUE);
  int i = m_List.GetCurSel();
  m_List.GetText(i,W);
  i = W.Find("\t");  
  key = W.Left(i);
  m_Text ="(" + key + ")  " + W.Mid(i+1);
	CDialog::OnOK();
}
